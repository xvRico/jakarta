/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.mycompany.hashmapprintlist;

import jakarta.inject.Named;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;

/**
 *
 * @author Adam Kalinko
 */
@Named(value = "requestBean")
@RequestScoped
public class RequestBean {
    
    @Inject
    private ApplicationBean applicationBean;
    private String name;
    private String surname;
    private int id;

    public void setName(String name)
    {
        this.name = name;
    }
    public String getName()
    {
        return name;
    }
    public void setSurname(String surname)
    {
        this.surname = surname;
    }
    public String getSurname()
    {
        return surname;
    }
    public void setId(int id)
    {
        this.id = id;
    }
    public int getId()
    {
        return id;
    }
    
    public void addPerson()
    {
        applicationBean.addPerson(name, surname, id);
    }
    /**
     * Creates a new instance of GetData
     */
    public RequestBean() {
    }
    
}
