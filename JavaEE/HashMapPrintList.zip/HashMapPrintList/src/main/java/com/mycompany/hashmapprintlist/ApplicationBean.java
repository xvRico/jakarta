/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.mycompany.hashmapprintlist;

import jakarta.inject.Named;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Adam Kalinko
 */
@Named(value = "applicationBean")
@ApplicationScoped
public class ApplicationBean {
    
    public class Person{
        private String name;
        private String surname;
        private int id;
        Person(String name, String surname, int id)
        {
            this.name = name;
            this.surname = surname;
            this.id = id;
        }
        public void setName(String name)
    {
        this.name = name;
    }
    public String getName()
    {
        return name;
    }
    public void setSurname(String surname)
    {
        this.surname = surname;
    }
    public String getSurname()
    {
        return surname;
    }
    public void setId(int id)
    {
        this.id = id;
    }
    public int getId()
    {
        return id;
    }
    }
    
    private List<Person> personList = new ArrayList<Person>();

    public void addPerson(String name, String surname, int id)
    {
        personList.add(new Person(name, surname, id));
    }
    /**
     * Creates a new instance of UserData
     */
    
    public List<Person> getPersonList()
    {
        return personList;
    }
    public ApplicationBean() {
    }
    
}
