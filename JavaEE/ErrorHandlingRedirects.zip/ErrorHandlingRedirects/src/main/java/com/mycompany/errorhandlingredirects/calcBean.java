/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.mycompany.errorhandlingredirects;

import jakarta.inject.Named;
import jakarta.enterprise.context.RequestScoped;

/**
 *
 * @author Adam Kalinko
 */
@Named(value = "calcBean")
@RequestScoped
public class calcBean {

    private float a;
    private float b;
    private float result = 0;
    private String operation;
    
    public void setA(float a)
    {
        this.a = a;
    }
    public float getA()
    {
        return a;
    }
    public void setB(float b)
    {
        this.b = b;
    }
    public float getb()
    {
        return b;
    }
    public float getResult()
    {
        return result;
    }
    public String getOperation()
    {
        return operation;
    }
    public String add()
    {
        result = a+b;
        operation = "add";
        return "result";
    }
    public String minus()
    {
        result = a-b;
        operation = "minus";
        return "result";
    }
    public String mult()
    {
        result = a*b;
        operation = "mult";
        return "result";
    }
    public String divide()
    {
        if(b == 0)
        {
            return "error";
        }else
        {
            result = a/b;
            operation = "divide";
            return "result";
        }
    }
    /**
     * Creates a new instance of calcBean
     */
    public calcBean() {
    }
    
}
