/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.errorhandlingredirects;

import jakarta.servlet.ServletContext;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 *
 * @author Adam Kalinko
 */
@WebServlet(name = "Calc", urlPatterns = {"/Calc"})
public class Calc extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        ServletContext application = request.getServletContext();
        if(request.getParameter("a") != null && request.getParameter("b") != null)
    {
    float a = Float.parseFloat(request.getParameter("a"));
    float b = Float.parseFloat(request.getParameter("b"));
    session.setAttribute("a", a);
    session.setAttribute("b", b);
    if (request.getParameter("add") != null)
    {
        session.setAttribute("result", (Float) (a+b));
        session.setAttribute("function", "add");
        response.sendRedirect("Result");
    }
    if(request.getParameter("minus") != null)
    {
        session.setAttribute("result", (Float) (a-b));
        session.setAttribute("function", "minus");
        response.sendRedirect("Result");
    }
    if(request.getParameter("mult") != null)
    {
        session.setAttribute("result", (Float) (a*b));
        session.setAttribute("function", "mult");
        response.sendRedirect("Result");
    }
    if(request.getParameter("div") != null)
    {
        if(b == 0)
        {
            response.sendRedirect("DivError");
            return;
        }else
        {
        session.setAttribute("result", (Float) (a/b));
        session.setAttribute("function", "div");
        response.sendRedirect("Result");
        }
    }
}
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
out.println("<html>");
out.println("    <head>");
out.println("        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
out.println("        <title>JSP Page Servlet</title>");
out.println("    </head>");
out.println("    <body>");
out.println("        <h1>Calculator</h1>");
out.println("        <form method=\"get\">");
out.println("            <input type=\"text\" name=\"a\" value=\"\" required=\"true\" oninvalid=\"Please enter first value!\" />");
out.println("            <input type=\"text\" name=\"b\" value=\"\" required=\"true\" oninvalid=\"Please enter second value!\" />");
out.println("            <button type=\"submit\" name=\"add\" value=\"true\">Add</button>");
out.println("            <button type=\"submit\" name=\"minus\" value=\"true\">Minus</button>");
out.println("            <button type=\"submit\" name=\"mult\" value=\"true\">Multiply</button>");
out.println("            <button type=\"submit\" name=\"div\" value=\"true\">Divide</button>");
out.println("        </form>");
out.println("    </body>");
out.println("</html>");

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
