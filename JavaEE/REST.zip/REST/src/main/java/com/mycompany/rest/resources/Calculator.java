package com.mycompany.rest.resources;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

@Path("calculator")
@Produces(MediaType.APPLICATION_JSON)
public class Calculator {

    private static final List<String> history = new ArrayList<>();
    private static String lastResult = "No calculations yet";
    
    @GET
    @Path("add")
    public Response add(@QueryParam("a") double a, @QueryParam("b") double b) {
        double result = a + b;
        lastResult = "Addition: " + result;
        history.add(lastResult);
        return Response.ok(result).build();
    }

    @GET
    @Path("subtract")
    public Response subtract(@QueryParam("a") double a, @QueryParam("b") double b) {
        double result = a - b;
        lastResult = "Subtraction: " + result;
        history.add(lastResult);
        return Response.ok(result).build();
    }

    @GET
    @Path("multiply/{a}/{b}")
    public Response multiply(@PathParam("a") double a, @PathParam("b") double b) {
        double result = a * b;
        lastResult = "Multiplication: " + result;
        history.add(lastResult);
        return Response.ok(result).build();
    }

    @GET
    @Path("divide/{a}/{b}")
    public Response divide(@PathParam("a") double a, @PathParam("b") double b) {
        if (b == 0) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("Error: Division by zero is not allowed.")
                    .build();
        }
        double result = a / b;
        lastResult = "Division: " + result;
        history.add(lastResult);
        return Response.ok(result).build();
    }

    @GET
    @Path("last")
    public Response getLastResult() {
        return Response.ok("{\"lastResult\":\"" + lastResult + "\"}").build();
    }

    @GET
    @Path("history")
    public Response getHistory() {
        return Response.ok(history).build();
    }
}
